# G1Bank_WebApp

G1Bank WebApp for Software Engineering Class at ECSU

# To Run Locally

Make sure you use the requirements.txt file in this repo to prepare your virtual environment 

# Some More Info

I have several comments all over to help explain what each file does

# Before starting on your work & before you push

Always pull before you start working on your project and before you push in case someone has done any work since the last time you pulled - you wouldn’t want anyone’s work to get lost or to have to resolve many coding conflicts.

# Branching

Once we split up the work, We should create branches for each feature/webpage we are working on individually and only merge to the main branch when it's done and working on your local machine. 