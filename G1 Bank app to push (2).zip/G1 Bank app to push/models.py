from __init__ import app, db
#define data objects as classes here